import express from "express";
import { createServer } from "http";
import { Client, GatewayIntentBits, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import axios from 'axios';

const app = express();
const httpServer = createServer(app);

app.get('/', (_req, res) => {
  res.send('Discord bot is running!');
});

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', bot: client.isReady() ? 'online' : 'offline' });
});

const port = parseInt(process.env.PORT || "5000", 10);
httpServer.listen(
  {
    port,
    host: "0.0.0.0",
    reusePort: true,
  },
  () => {
    console.log(`Keep-alive server running on port ${port}`);
  },
);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const PREFIX = ';';

client.once('ready', () => {
  console.log(`Bot is ready! Logged in as ${client.user?.tag}`);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const command = args.shift()?.toLowerCase();

  if (command === 'koral') {
    await handleKoralCommand(message, args);
  } else if (command === 'customize') {
    await handleCustomizeCommand(message, args);
  }
});

async function handleKoralCommand(message: any, args: string[]) {
  if (args.length === 0) {
    return message.reply('Please provide a user ID!');
  }

  const userId = args[0];

  try {
    await message.channel.sendTyping();

    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.5',
      'Connection': 'keep-alive',
    };

    const fetchData = async (url: string) => {
      try {
        const response = await axios.get(url, { timeout: 15000, headers });
        return response.data;
      } catch (err: any) {
        console.log(`Failed to fetch ${url}: ${err.message}`);
        return null;
      }
    };

    const [
      currencyData,
      userData,
      followingsData,
      usernameHistoryData,
      premiumData,
      collectiblesData,
      badgesData,
      robloxBadgesData,
      avatarData,
      inventoryData,
    ] = await Promise.all([
      fetchData(`https://aftwld.fun/apisite/economy/v1/users/${userId}/currency`),
      fetchData(`https://aftwld.fun/apisite/users/v1/users/${userId}`),
      fetchData(`https://aftwld.fun/apisite/friends/v1/users/${userId}/followings/count`),
      fetchData(`https://aftwld.fun/apisite/users/v1/users/${userId}/username-history?limit=100&cursor=`),
      fetchData(`https://aftwld.fun/apisite/premiumfeatures/v1/users/${userId}/validate-membership`),
      fetchData(`https://aftwld.fun/apisite/inventory/v1/users/${userId}/assets/collectibles?limit=5000`),
      fetchData(`https://aftwld.fun/apisite/accountinformation/v1/users/${userId}/badges`),
      fetchData(`https://aftwld.fun/apisite/accountinformation/v1/users/${userId}/roblox-badges`),
      fetchData(`https://aftwld.fun/apisite/avatar/v1/users/${userId}/avatar`),
      fetchData(`https://aftwld.fun/users/${userId}/inventory`),
    ]);

    console.log('User Data:', JSON.stringify(userData, null, 2));
    console.log('Currency Data:', JSON.stringify(currencyData, null, 2));
    console.log('Avatar Data:', JSON.stringify(avatarData, null, 2));
    console.log('Inventory Data:', JSON.stringify(inventoryData, null, 2));

    const allDataNull = !userData && !currencyData && !avatarData && !followingsData && !inventoryData;
    if (allDataNull) {
      return message.reply('The KORAL API is currently unavailable. Please try again later or check https://aftwld.fun for status updates.');
    }

    const username = userData?.name || userData?.displayName || userData?.username || userData?.Username || inventoryData?.username || inventoryData?.name || 'Unknown';
    const currency = currencyData?.robux ?? currencyData?.balance ?? currencyData?.Robux ?? 0;
    const followingCount = followingsData?.count ?? followingsData?.Count ?? 0;
    const isPremium = premiumData === true || premiumData?.isPremium === true || premiumData?.IsPremium === true;
    
    let collectiblesCount = 0;
    if (collectiblesData?.data) {
      collectiblesCount = Array.isArray(collectiblesData.data) ? collectiblesData.data.length : 0;
    } else if (Array.isArray(collectiblesData)) {
      collectiblesCount = collectiblesData.length;
    }
    
    let rap = 0;
    let inventoryItemCount = 0;
    if (inventoryData) {
      rap = inventoryData.rap ?? inventoryData.RAP ?? inventoryData.totalRap ?? inventoryData.totalRAP ?? 0;
      inventoryItemCount = inventoryData.count ?? inventoryData.itemCount ?? inventoryData.totalItems ?? 0;
      if (inventoryData.items && Array.isArray(inventoryData.items)) {
        inventoryItemCount = inventoryData.items.length;
      }
    }
    
    const badgeCount = Array.isArray(badgesData) ? badgesData.length : (badgesData?.data?.length ?? 0);
    const robloxBadgeCount = Array.isArray(robloxBadgesData) ? robloxBadgesData.length : (robloxBadgesData?.data?.length ?? 0);
    
    let usernameHistory = 'None';
    if (usernameHistoryData?.data && Array.isArray(usernameHistoryData.data)) {
      usernameHistory = usernameHistoryData.data.slice(0, 5).map((h: any) => h.name || h.Name || h.username).filter(Boolean).join(', ') || 'None';
    }
    
    const avatarImageUrl = avatarData?.imageUrl || avatarData?.ImageUrl || avatarData?.thumbnailUrl || avatarData?.image || null;

    const profileUrl = `https://aftwld.fun/users/${userId}/profile`;
    
    const embed = new EmbedBuilder()
      .setColor(0x0099FF)
      .setTitle(`User Profile: ${username}`)
      .setURL(profileUrl)
      .addFields(
        { name: 'Username', value: String(username), inline: true },
        { name: 'User ID', value: String(userId), inline: true },
        { name: 'Currency Balance', value: String(currency), inline: true },
        { name: 'Follower Count', value: String(followingCount), inline: true },
        { name: 'Premium Status', value: isPremium ? 'Yes' : 'No', inline: true },
        { name: 'Collectibles Count', value: String(collectiblesCount), inline: true },
        { name: 'RAP (Recent Average Price)', value: String(rap), inline: true },
        { name: 'Inventory Items', value: String(inventoryItemCount), inline: true },
        { name: 'Badge Count', value: String(badgeCount), inline: true },
        { name: 'Roblox Badge Count', value: String(robloxBadgeCount), inline: true },
        { name: 'Username History', value: String(usernameHistory), inline: false },
        { name: 'Profile Link', value: `[View Full Profile](${profileUrl})`, inline: false }
      )
      .setTimestamp();

    if (avatarImageUrl) {
      embed.setThumbnail(avatarImageUrl);
    }

    message.reply({ embeds: [embed] });
  } catch (error: any) {
    console.error('Error fetching Koral data:', error.message);
    message.reply('Sorry, there was an error fetching the user data. Please check the user ID and try again.');
  }
}

async function handleCustomizeCommand(message: any, args: string[]) {
  if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
    return message.reply('You need Administrator permission to use this command!');
  }

  if (args[0] !== 'avatar' || args.length < 2) {
    return message.reply('Usage: `;customize avatar <image_url>`');
  }

  const imageUrl = args[1];

  try {
    await client.user?.setAvatar(imageUrl);
    message.reply('Bot avatar updated successfully!');
  } catch (error: any) {
    console.error('Error setting avatar:', error.message);
    message.reply('Failed to update avatar. Please make sure the image URL is valid.');
  }
}

const TOKEN = process.env.TOKEN;

if (!TOKEN) {
  console.error('ERROR: TOKEN environment variable is not set!');
  process.exit(1);
}

client.login(TOKEN);
