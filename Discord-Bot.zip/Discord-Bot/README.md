# Discord Bot with AI, Koral, and Customize Commands

A fully functional Discord bot built with discord.js v14 that includes three powerful commands.

## Features

### Commands

1. **;ai <message>** - AI Chat
   - Uses OpenAI's gpt-4o-mini model
   - Sends your message and returns AI-generated responses
   - Example: `;ai What is the meaning of life?`

2. **;koral <userid>** - User Profile Lookup
   - Fetches comprehensive user data from multiple API endpoints
   - Displays data in a rich embed including:
     - Username and User ID
     - Currency balance
     - Follower count
     - Premium status
     - Collectibles, badges, and Roblox badges count
     - Username history
     - Avatar image
   - Example: `;koral 123456789`

3. **;customize avatar <image_url>** - Bot Avatar Customization
   - Administrator-only command
   - Changes the bot's avatar to the provided image URL
   - Example: `;customize avatar https://example.com/image.png`

## Setup Instructions

### 1. Configure Environment Variables

The bot requires two secret environment variables (already configured in Replit Secrets):

- `TOKEN` - Your Discord bot token
- `OPENAI_API_KEY` - Your OpenAI API key

### 2. Get Your Discord Bot Token

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application
3. Go to the "Bot" section and create a bot
4. Copy the bot token and add it to your Replit Secrets as `TOKEN`
5. Enable the following Privileged Gateway Intents:
   - Message Content Intent
   - Server Members Intent (optional)

### 3. Invite the Bot to Your Server

Use this URL format (replace YOUR_CLIENT_ID with your application's client ID):
```
https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&scope=bot
```

### 4. Run the Bot

To run the bot, execute:
```bash
node index.js
```

The bot will:
- Start an Express server on port 3000 (keeps the bot alive on Replit)
- Connect to Discord
- Listen for commands with the prefix `;`

## Technical Details

### Dependencies
- `discord.js` v14 - Discord API wrapper
- `axios` - HTTP client for API requests
- `express` - Web server for keep-alive

### Architecture
- All code is in a single `index.js` file for simplicity
- Express server runs on port 3000 for Replit keep-alive
- Discord bot uses Gateway Intents for message handling
- Prefix-based command system (`;`)

### API Endpoints Used (;koral command)
The bot fetches data from 11 different endpoints to compile a comprehensive user profile.

## Error Handling

- Invalid OpenAI API key: Returns error message
- Invalid user ID in ;koral: Returns error message
- Missing administrator permission: Returns permission denied
- Invalid image URL in ;customize: Returns error message

## Notes

- The bot responds to messages in any channel it has access to
- All commands must start with the `;` prefix
- The bot will ignore messages from other bots
- AI responses are truncated to 2000 characters (Discord limit)
