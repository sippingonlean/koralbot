import { Client, GatewayIntentBits, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import axios from 'axios';
import express from 'express';

const app = express();
const PORT = 3000;

app.get('/', (req, res) => {
  res.send('Discord bot is running!');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Keep-alive server running on port ${PORT}`);
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const PREFIX = ';';

client.once('ready', () => {
  console.log(`Bot is ready! Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'ai') {
    await handleAiCommand(message, args);
  } else if (command === 'koral') {
    await handleKoralCommand(message, args);
  } else if (command === 'customize') {
    await handleCustomizeCommand(message, args);
  }
});

async function handleAiCommand(message, args) {
  if (args.length === 0) {
    return message.reply('Please provide a message for the AI!');
  }

  const userMessage = args.join(' ');

  try {
    await message.channel.sendTyping();

    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'user',
            content: userMessage,
          },
        ],
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const aiResponse = response.data.choices[0].message.content;
    
    if (aiResponse.length > 2000) {
      return message.reply(aiResponse.substring(0, 1997) + '...');
    }
    
    message.reply(aiResponse);
  } catch (error) {
    console.error('Error calling OpenAI API:', error.response?.data || error.message);
    message.reply('Sorry, there was an error processing your request. Please check the API key and try again.');
  }
}

async function handleKoralCommand(message, args) {
  if (args.length === 0) {
    return message.reply('Please provide a user ID!');
  }

  const userId = args[0];

  try {
    await message.channel.sendTyping();

    const endpoints = [
      `https://aftwld.fun/apisite/economy/v1/users/${userId}/currency`,
      `https://aftwld.fun/users/profile/robloxcollections-json?userId=${userId}`,
      `https://aftwld.fun/apisite/users/v1/users/authenticated`,
      `https://aftwld.fun/apisite/users/v1/users/${userId}`,
      `https://aftwld.fun/apisite/friends/v1/users/${userId}/followings/count`,
      `https://aftwld.fun/apisite/users/v1/users/${userId}/username-history?limit=100&cursor=`,
      `https://aftwld.fun/apisite/premiumfeatures/v1/users/${userId}/validate-membership`,
      `https://aftwld.fun/apisite/inventory/v1/users/${userId}/assets/collectibles?limit=5000`,
      `https://aftwld.fun/apisite/accountinformation/v1/users/${userId}/badges`,
      `https://aftwld.fun/apisite/accountinformation/v1/users/${userId}/roblox-badges`,
      `https://aftwld.fun/apisite/avatar/v1/users/${userId}/avatar`,
    ];

    const results = await Promise.allSettled(
      endpoints.map(url => axios.get(url).catch(err => ({ error: err.message })))
    );

    const [
      currencyRes,
      collectionsRes,
      authenticatedRes,
      userRes,
      followingsRes,
      usernameHistoryRes,
      premiumRes,
      collectiblesRes,
      badgesRes,
      robloxBadgesRes,
      avatarRes,
    ] = results.map(r => r.status === 'fulfilled' ? r.value.data || r.value : null);

    const username = userRes?.name || userRes?.displayName || 'Unknown';
    const currency = currencyRes?.robux || 0;
    const followingCount = followingsRes?.count || 0;
    const isPremium = premiumRes ? (premiumRes === true || premiumRes.isPremium === true) : false;
    const collectiblesCount = collectiblesRes?.data?.length || 0;
    const badgeCount = badgesRes?.length || 0;
    const robloxBadgeCount = robloxBadgesRes?.length || 0;
    const usernameHistory = usernameHistoryRes?.data?.slice(0, 5).map(h => h.name).join(', ') || 'None';
    const avatarImageUrl = avatarRes?.imageUrl || null;

    const embed = new EmbedBuilder()
      .setColor(0x0099FF)
      .setTitle(`User Profile: ${username}`)
      .addFields(
        { name: 'Username', value: username, inline: true },
        { name: 'User ID', value: userId, inline: true },
        { name: 'Currency Balance', value: currency.toString(), inline: true },
        { name: 'Follower Count', value: followingCount.toString(), inline: true },
        { name: 'Premium Status', value: isPremium ? 'Yes' : 'No', inline: true },
        { name: 'Collectibles Count', value: collectiblesCount.toString(), inline: true },
        { name: 'Badge Count', value: badgeCount.toString(), inline: true },
        { name: 'Roblox Badge Count', value: robloxBadgeCount.toString(), inline: true },
        { name: 'Username History', value: usernameHistory || 'None', inline: false }
      )
      .setTimestamp();

    if (avatarImageUrl) {
      embed.setThumbnail(avatarImageUrl);
    }

    message.reply({ embeds: [embed] });
  } catch (error) {
    console.error('Error fetching Koral data:', error.message);
    message.reply('Sorry, there was an error fetching the user data. Please check the user ID and try again.');
  }
}

async function handleCustomizeCommand(message, args) {
  if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
    return message.reply('You need Administrator permission to use this command!');
  }

  if (args[0] !== 'avatar' || args.length < 2) {
    return message.reply('Usage: `;customize avatar <image_url>`');
  }

  const imageUrl = args[1];

  try {
    await client.user.setAvatar(imageUrl);
    message.reply('Bot avatar updated successfully!');
  } catch (error) {
    console.error('Error setting avatar:', error.message);
    message.reply('Failed to update avatar. Please make sure the image URL is valid.');
  }
}

const TOKEN = process.env.TOKEN;

if (!TOKEN) {
  console.error('ERROR: TOKEN environment variable is not set!');
  process.exit(1);
}

if (!process.env.OPENAI_API_KEY) {
  console.warn('WARNING: OPENAI_API_KEY is not set. The ;ai command will not work.');
}

client.login(TOKEN);
